
from flask import Flask, send_from_directory, abort, render_template_string
import csv
from datetime import datetime
import os

app = Flask(__name__)

CATALOG = "ukb/token_catalog.csv"
TOKEN_BASE = "ukb/token"

def load_tokens():
    tokens = []
    if not os.path.exists(CATALOG):
        return tokens

    with open(CATALOG, newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["created_at"] = datetime.fromisoformat(row["created_at"])
            row["expires_at"] = datetime.fromisoformat(row["expires_at"])
            row["expired"] = datetime.now() > row["expires_at"]
            tokens.append(row)
    return tokens

@app.route("/")
def home():
    return "<h1>✅ Token System Active</h1><p>Go to <a href='/dashboard'>/dashboard</a></p>"

@app.route("/token/<token_id>")
def serve_token(token_id):
    path = os.path.join(TOKEN_BASE, token_id)
    if not os.path.exists(path):
        return abort(404, f"❌ Token '{token_id}' not found.")

    index_file = os.path.join(path, "index.html")
    if not os.path.exists(index_file):
        return abort(404, "📄 index.html not found.")

    tokens = load_tokens()
    token = next((t for t in tokens if t["token"] == token_id), None)
    if not token or token["status"] != "active" or token["expired"]:
        return abort(403, f"⚠️ Token '{token_id}' expired or revoked.")

    return send_from_directory(path, "index.html")

@app.route("/dashboard")
def dashboard():
    tokens = load_tokens()
    active = [t for t in tokens if t["status"] == "active" and not t["expired"]]
    expired = [t for t in tokens if t["expired"] or t["status"] != "active"]

    html = """
    <html><head>
      <title>Token Dashboard</title>
      <style>
        body { font-family: sans-serif; background: #f9f9f9; padding: 20px; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        th, td { padding: 8px 12px; border: 1px solid #ccc; }
        th { background-color: #eee; }
        tr.expired { opacity: 0.5; }
        a { text-decoration: none; color: #0645AD; }
      </style>
    </head><body>
      <h1>🎓 Intern Token Dashboard</h1>
      <h2>✅ Active Tokens</h2>
      <table>
        <tr><th>Intern</th><th>Token</th><th>Expires</th><th>Link</th></tr>
        {% for t in active %}
        <tr>
          <td>{{ t.intern }}</td>
          <td>{{ t.token }}</td>
          <td>{{ t.expires_at.strftime('%Y-%m-%d %H:%M') }}</td>
          <td><a href="/token/{{ t.token }}">View</a></td>
        </tr>
        {% endfor %}
      </table>

      <h2>❌ Expired / Revoked</h2>
      <table>
        <tr><th>Intern</th><th>Token</th><th>Status</th><th>Expires</th></tr>
        {% for t in expired %}
        <tr class="expired">
          <td>{{ t.intern }}</td>
          <td>{{ t.token }}</td>
          <td>{{ t.status }}</td>
          <td>{{ t.expires_at.strftime('%Y-%m-%d %H:%M') }}</td>
        </tr>
        {% endfor %}
      </table>
    </body></html>
    """
    return render_template_string(html, active=active, expired=expired)

if __name__ == "__main__":
    app.run(debug=True)
